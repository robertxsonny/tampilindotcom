<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width" />
<!-- <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Language" content="id">
<meta name="description"
	content="Tampilin.id, segera hadir di Indonesia. Buat kamu yang ingin cari kerja, daganganmu tampil lebih cantik, ingin karyamu dikenal orang, bahkan sampai ingin cari jodoh, semuanya ada di Tampilin.id. Stay tuned guys!">
<meta property="og:title" content="Tampilin.id: Segera Hadir">
<meta property="og:description"
	content="Tampilin.id, segera hadir di Indonesia. Buat kamu yang ingin cari kerja, daganganmu tampil lebih cantik, ingin karyamu dikenal orang, bahkan sampai ingin cari jodoh, semuanya ada di Tampilin.id. Stay tuned guys!">
<meta property="og:type" content="website">
<meta property="og:url" content="http://tampilin.id">
<meta property="og:site_name" content="Tampilin.id">
<meta name="revisit-after" content="30 days">
<meta name="distribution" content="web">
<meta name="robots" content="index, follow"> -->
<!-- GOOGLE FONTS -->
<link rel="shortcut icon" type="image/x-icon"
	href="http://tampilin-local.com/images/icon.ico" />
	<link rel="shortcut icon" type="image/png"
	href="images/icon.png" />
<link
	href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300'
	rel='stylesheet' type='text/css'>
<!-- CUSTOM STYLES -->
<link rel="stylesheet" href="/css/style.css" type="text/css" />
<title>Coming Soon: Tampilin.id</title>
</head>
<body>
	<div class="cover">
		<div class="content">
			<div class="title">
				<div class="main">
					<h1 class="sub">This site is under construction</h1>
					<h1 class="sub">Developed by</h1>
					<div class="logo"></div>
					<!-- <span>T</span><span>a</span><span>m</span><span>p</span><span>i</span><span>l</span><span>i</span><span>n</span><span>.</span><span>c</span><span>o</span><span>m</span> -->
				</div>
			</div>
		</div>
	</div>
</body>
</html>